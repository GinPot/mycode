#ifndef KVM__KVM_FDT_H
#define KVM__KVM_FDT_H

#include "arm-common/fdt-arch.h"

#endif /* KVM__KVM_FDT_H */
