
#define KVM_ARM_PMUv3_PPI			23

void pmu__generate_fdt_nodes(void *fdt, struct kvm *kvm);
