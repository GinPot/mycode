#ifndef X86__FDT_ARCH_H
#define X86__FDT_ARCH_H

enum phandles {PHANDLE_RESERVED = 0, PHANDLES_MAX};

#endif /* KVM__KVM_FDT_H */
