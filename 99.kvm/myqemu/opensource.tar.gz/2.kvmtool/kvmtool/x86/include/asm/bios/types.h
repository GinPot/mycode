#ifndef __X86_ASM_BIOS_TYPES_H
#define __X86_ASM_BIOS_TYPES_H

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef unsigned long long u64;

#endif
