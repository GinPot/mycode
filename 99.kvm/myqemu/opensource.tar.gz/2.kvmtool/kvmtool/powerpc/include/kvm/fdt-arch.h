#ifndef KVM__KVM_FDT_H
#define KVM__KVM_FDT_H

enum phandles {PHANDLE_RESERVED = 0, PHANDLE_XICP, PHANDLES_MAX};

#endif /* KVM__KVM_FDT_H */
