#ifndef KVM__LINUX_PREFETCH_H
#define KVM__LINUX_PREFETCH_H

static inline void prefetch(void *a __attribute__((unused))) { }

#endif
