Please copy current directory into [android_project]/external/libdrm/tests/.

Any other questions, please contact me by e-mail(343005384@qq.com).