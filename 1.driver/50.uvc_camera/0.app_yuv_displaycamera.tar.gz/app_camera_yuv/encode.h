#ifndef _ENCODE_H
#define _ENCODE_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vencoder.h"
#include <sys/time.h>
#include <time.h>
#include <memoryAdapter.h>
#include <math.h>
#include <sys/shm.h>

#include "camera.h"

#define H264IMAGE_WIDTH		IMAGE_WIDTH
#define H264IMAGE_HEIGHT	IMAGE_HEIGHT
#define H264PERFRAME		PERFRAME

#define ROI_NUM 4
#define ALIGN_XXB(y, x) (((x) + ((y)-1)) & ~((y)-1))


typedef struct {
    VencHeaderData          sps_pps_data;
    VencH264Param           h264Param;
    VencMBModeCtrl          h264MBMode;
    VencMBInfo              MBInfo;
    VencH264FixQP           fixQP;
    VencSuperFrameConfig    sSuperFrameCfg;
    VencH264SVCSkip         SVCSkip; // set SVC and skip_frame
    VencH264AspectRatio     sAspectRatio;
    VencH264VideoSignal     sVideoSignal;
    VencCyclicIntraRefresh  sIntraRefresh;
    VencROIConfig           sRoiConfig[ROI_NUM];
    VeProcSet               sVeProcInfo;
    VencOverlayInfoS        sOverlayInfo;
    VencSmartFun            sH264Smart;
}h264_func_t;


int init_encode(FILE *H264_file);
int exit_encode(void);
int run_encode(unsigned char *yuv420PBuffer, FILE *H264_file);



#endif	/* _ENCODE_H */