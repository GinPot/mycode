#include "camera.h"
#include "encode.h"
#include "sps_decode.h" 


void OutPutFpsInfo()
{
	static int fps = 1; 
	struct timezone tz;
	static struct timeval tv_old, tv_new;
	float usec = 0, sec = 0, time = 0;

	if((fps%60) == 0){
		fps = 1;
		gettimeofday(&tv_old, &tz);
	}else{
		fps++;
		if(60 == fps){
			gettimeofday(&tv_new, &tz);
			if(tv_new.tv_usec >= tv_old.tv_usec){
				usec = tv_new.tv_usec - tv_old.tv_usec;
				sec = tv_new.tv_sec - tv_old.tv_sec;
			}else{
				usec = 1000000 + tv_new.tv_usec - tv_old.tv_usec;
				sec = tv_new.tv_sec - tv_old.tv_sec - 1;
			}
			time = sec + usec/1000000;
			printf("the fps is %f\n", 60/time);
		}
	}
}

void yuyv_to_yuv420P(unsigned char *in, unsigned char *out, int width, int height)  
{  
	unsigned char *y, *u, *v;  
	int i, j, offset = 0, yoffset = 0;  
	 
	y = out;                                    //yuv420的y放在前面  
	u = out + (width * height);                 //yuv420的u放在y后  
	v = out + (width * height * 5 / 4);         //yuv420的v放在u后  
	//总共size = width * height * 3 / 2  
	 
	for(j = 0; j < height; j++)  
	{  
		yoffset = 2 * width * j;  
		for(i = 0; i < width * 2; i = i + 4)  
		{  
			offset = yoffset + i;  
			*(y ++) = *(in + offset);  
			*(y ++) = *(in + offset + 2);  
			if(j % 2 == 1)                      //抛弃奇数行的UV分量  
			{  
				*(u ++) = *(in + offset + 1);  
				*(v ++) = *(in + offset + 3);  
			}  
		}  
	}  
} 





struct v4l2_buffer video_buffer;
int main(int argc, char **argv)
{
	FILE *H264_file, *yuv_file;
	int video_fd;
	struct buffer_info bufferinfo[BUFFER_NUM];


	
	unsigned char *yuv420PBuffer = (unsigned char*)malloc(IMAGE_WIDTH * IMAGE_HEIGHT * 1.5);
	memset(yuv420PBuffer, 0, IMAGE_WIDTH * IMAGE_HEIGHT * 1.5);
	


	if(InitUvcCamera(&video_fd, bufferinfo) < 0){
		printf("init uvc camera fail\n");
		return 0;
	}
	
	
	H264_file = fopen("./out.h264", "wb");
	printf("\n");
	init_encode(H264_file);
	RTMP264_Connect("rtmp://192.168.137.11:1935/live/111");

	//yuv_file=fopen("./out.yuv", "wb");
	
	while(1){
		memset(&video_buffer, 0, sizeof(&video_buffer));
		video_buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		video_buffer.memory = V4L2_MEMORY_DMABUF;
		if(ioctl(video_fd, VIDIOC_DQBUF, &video_buffer) < 0){		//v4l2:取出队列采集完毕的缓冲区
			printf("get camera buffer fail\n");
			return 0;
		}
       
        
		yuyv_to_yuv420P(bufferinfo[video_buffer.index].image_buffer, yuv420PBuffer, IMAGE_WIDTH, IMAGE_HEIGHT);
		//fwrite(yuv420PBuffer, sizeof(unsigned char) * IMAGE_WIDTH * IMAGE_HEIGHT * 1.5, 1, yuv_file);
		if(run_encode(yuv420PBuffer, H264_file) < 0)
			goto out;
        
        
        
		
		if(ioctl(video_fd, VIDIOC_QBUF, &video_buffer) < 0){		//v4l2:将缓冲区再放入队列
			printf("set camera buffer fail\n");
			return 0;
		}
		
		OutPutFpsInfo();
	}
	
out:
	fclose(H264_file);
	//fclose(yuv_file);
	exit_encode();

	return 0;
}








