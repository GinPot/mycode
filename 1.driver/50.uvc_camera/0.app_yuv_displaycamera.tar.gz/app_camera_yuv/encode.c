#include "encode.h"
#include "sps_decode.h"









static long long GetNowUs()
{
    struct timeval now;
    gettimeofday(&now, NULL);
    return now.tv_sec * 1000000 + now.tv_usec;
}

static void init_mb_mode(VencMBModeCtrl *pMBMode)
{
    unsigned int mb_num;
    unsigned int j;

    mb_num = (ALIGN_XXB(16, H264IMAGE_WIDTH) >> 4)
                * (ALIGN_XXB(16, H264IMAGE_HEIGHT) >> 4);
    pMBMode->p_info = malloc(sizeof(VencMBModeCtrlInfo) * mb_num);
    pMBMode->mode_ctrl_en = 1;

    for (j = 0; j < mb_num / 2; j++)
    {
        pMBMode->p_info[j].mb_en = 1;
        pMBMode->p_info[j].mb_skip_flag = 0;
        pMBMode->p_info[j].mb_qp = 22;
    }
    for (; j < mb_num; j++)
    {
        pMBMode->p_info[j].mb_en = 1;
        pMBMode->p_info[j].mb_skip_flag = 0;
        pMBMode->p_info[j].mb_qp = 32;
    }
}

static void init_mb_info(VencMBInfo *MBInfo)
{

    MBInfo->num_mb = (ALIGN_XXB(16, H264IMAGE_WIDTH) *
                            ALIGN_XXB(16, H264IMAGE_HEIGHT)) >> 8;

    MBInfo->p_para = (VencMBInfoPara *)malloc(sizeof(VencMBInfoPara) * MBInfo->num_mb);
    if(MBInfo->p_para == NULL)
    {
        printf("malloc MBInfo->p_para error\n");
        return;
    }
    printf("mb_num:%d, mb_info_queue_addr:%p\n", MBInfo->num_mb, MBInfo->p_para);
}

static void init_fix_qp(VencH264FixQP *fixQP)
{
    fixQP->bEnable = 1;
    fixQP->nIQp = 35;
    fixQP->nPQp = 35;
}

static void init_super_frame_cfg(VencSuperFrameConfig *sSuperFrameCfg)
{
    sSuperFrameCfg->eSuperFrameMode = VENC_SUPERFRAME_NONE;
    sSuperFrameCfg->nMaxIFrameBits = 30000*8;
    sSuperFrameCfg->nMaxPFrameBits = 15000*8;
}

static void init_svc_skip(VencH264SVCSkip *SVCSkip)
{
    SVCSkip->nTemporalSVC = T_LAYER_4;
    switch(SVCSkip->nTemporalSVC)
    {
        case T_LAYER_4:
            SVCSkip->nSkipFrame = SKIP_8;
            break;
        case T_LAYER_3:
            SVCSkip->nSkipFrame = SKIP_4;
            break;
        case T_LAYER_2:
            SVCSkip->nSkipFrame = SKIP_2;
            break;
        default:
            SVCSkip->nSkipFrame = NO_SKIP;
            break;
    }
}

static void init_aspect_ratio(VencH264AspectRatio *sAspectRatio)
{
    sAspectRatio->aspect_ratio_idc = 255;
    sAspectRatio->sar_width = 4;
    sAspectRatio->sar_height = 3;
}

static void init_video_signal(VencH264VideoSignal *sVideoSignal)
{
    sVideoSignal->video_format = 5;
    sVideoSignal->src_colour_primaries = 5;
    sVideoSignal->dst_colour_primaries = 8;
}

static void init_intra_refresh(VencCyclicIntraRefresh *sIntraRefresh)
{
    sIntraRefresh->bEnable = 1;
    sIntraRefresh->nBlockNumber = 10;
}

static void init_roi(VencROIConfig *sRoiConfig)
{
    sRoiConfig[0].bEnable = 1;
    sRoiConfig[0].index = 0;
    sRoiConfig[0].nQPoffset = 10;
    sRoiConfig[0].sRect.nLeft = 0;
    sRoiConfig[0].sRect.nTop = 0;
    sRoiConfig[0].sRect.nWidth = 352;
    sRoiConfig[0].sRect.nHeight = 288;

    sRoiConfig[1].bEnable = 1;
    sRoiConfig[1].index = 1;
    sRoiConfig[1].nQPoffset = 10;
    sRoiConfig[1].sRect.nLeft = 320;
    sRoiConfig[1].sRect.nTop = 180;
    sRoiConfig[1].sRect.nWidth = 320;
    sRoiConfig[1].sRect.nHeight = 180;

    sRoiConfig[2].bEnable = 1;
    sRoiConfig[2].index = 2;
    sRoiConfig[2].nQPoffset = 10;
    sRoiConfig[2].sRect.nLeft = 320;
    sRoiConfig[2].sRect.nTop = 180;
    sRoiConfig[2].sRect.nWidth = 320;
    sRoiConfig[2].sRect.nHeight = 180;

    sRoiConfig[3].bEnable = 1;
    sRoiConfig[3].index = 3;
    sRoiConfig[3].nQPoffset = 10;
    sRoiConfig[3].sRect.nLeft = 320;
    sRoiConfig[3].sRect.nTop = 180;
    sRoiConfig[3].sRect.nWidth = 320;
    sRoiConfig[3].sRect.nHeight = 180;
}



static void init_enc_proc_info(VeProcSet *ve_proc_set)
{
    ve_proc_set->bProcEnable = 1;
    ve_proc_set->nProcFreq = 3;
}


VideoEncoder* pVideoEnc = NULL;
h264_func_t h264_func;
VencBaseConfig baseConfig;
VencAllocateBufferParam bufferParam;
static int shmid;
static char *shm = NULL;			//分配的共享内存的原始首地址 
int init_encode(FILE *H264_file)
{

	
	
	unsigned int vbv_size = 20*1024*1024, i;
	VencHeaderData sps_pps_data;
	
    //create encoder
    pVideoEnc = VideoEncCreate(VENC_CODEC_H264);
	
	/******** init h264 param ********/
    h264_func.h264Param.bEntropyCodingCABAC = 1;
    h264_func.h264Param.nBitrate = 20 * H264IMAGE_WIDTH * H264IMAGE_HEIGHT;
    h264_func.h264Param.nFramerate = H264PERFRAME;
    h264_func.h264Param.nCodingMode = VENC_FRAME_CODING;
    h264_func.h264Param.nMaxKeyInterval = H264PERFRAME;
    h264_func.h264Param.sProfileLevel.nProfile = VENC_H264ProfileHigh;
    h264_func.h264Param.sProfileLevel.nLevel = VENC_H264Level51;
    h264_func.h264Param.sQPRange.nMinqp = 10;
    h264_func.h264Param.sQPRange.nMaxqp = 50;
    h264_func.h264Param.bLongRefEnable = 1;
    h264_func.h264Param.nLongRefPoc = 0;
	
    //h264_func.sH264Smart.img_bin_en = 1;
    //h264_func.sH264Smart.img_bin_th = 27;
    //h264_func.sH264Smart.shift_bits = 2;
    //h264_func.sH264Smart.smart_fun_en = 1;

    //init VencMBModeCtrl
    //init_mb_mode(&h264_func.h264MBMode);
    //init VencMBInfo
    //init_mb_info(&h264_func.MBInfo);
    //init VencH264FixQP
    //init_fix_qp(&h264_func.fixQP);
    //init VencSuperFrameConfig
    //init_super_frame_cfg(&h264_func.sSuperFrameCfg);
    //init VencH264SVCSkip
    //init_svc_skip(&h264_func.SVCSkip);
    //init VencH264AspectRatio
    //init_aspect_ratio(&h264_func.sAspectRatio);
    //init VencH264AspectRatio
    init_video_signal(&h264_func.sVideoSignal);
    //init CyclicIntraRefresh
    //init_intra_refresh(&h264_func.sIntraRefresh);
    //init VencROIConfig
    //init_roi(h264_func.sRoiConfig);
    //init proc info
    //init_enc_proc_info(&h264_func.sVeProcInfo);
    //init VencOverlayConfig
    //init_overlay_info(&h264_func.sOverlayInfo);

    VideoEncSetParameter(pVideoEnc, VENC_IndexParamH264Param, &h264_func.h264Param);
    VideoEncSetParameter(pVideoEnc, VENC_IndexParamSetVbvSize, &vbv_size);
	VideoEncSetParameter(pVideoEnc, VENC_IndexParamH264VideoSignal, &h264_func.sVideoSignal);
	/******** end init h264 param ********/
	
	
	/******** begin set baseConfig param ********/
	memset(&baseConfig, 0 ,sizeof(VencBaseConfig));
    baseConfig.memops = MemAdapterGetOpsS();
    if (baseConfig.memops == NULL)
    {
        printf("MemAdapterGetOpsS failed\n");
        return -1;
    }
    CdcMemOpen(baseConfig.memops);
    baseConfig.nInputWidth= H264IMAGE_WIDTH;
    baseConfig.nInputHeight = H264IMAGE_HEIGHT;
    baseConfig.nStride = H264IMAGE_WIDTH;
    baseConfig.nDstWidth = H264IMAGE_WIDTH;
    baseConfig.nDstHeight = H264IMAGE_HEIGHT;

    baseConfig.eInputFormat = VENC_PIXEL_YUV420P;
	
	VideoEncInit(pVideoEnc, &baseConfig);
	/******** end set baseConfig param********/
	
	memset(&bufferParam, 0 ,sizeof(VencAllocateBufferParam));
    bufferParam.nSizeY = H264IMAGE_WIDTH * H264IMAGE_HEIGHT;
    bufferParam.nSizeC = H264IMAGE_WIDTH * H264IMAGE_HEIGHT / 2;
    bufferParam.nBufferNum = 1;
	AllocInputBuffer(pVideoEnc, &bufferParam);
	
	
	
	VideoEncGetParameter(pVideoEnc, VENC_IndexParamH264SPSPPS, &sps_pps_data);
    fwrite(sps_pps_data.pBuffer, 1, sps_pps_data.nLength, H264_file);
    //printf("sps_pps_data.nLength: %d\n", sps_pps_data.nLength);
	for(i = 0; i < sps_pps_data.nLength; i++)
		printf("0x%x ", *(sps_pps_data.pBuffer + i));
	printf("\n");

	init_sps_pps_data(sps_pps_data.pBuffer, sps_pps_data.nLength);

	
	shmid = shmget((key_t)5279, 1, 0666|IPC_CREAT);	//创建共享内存
    if(shmid == -1)
    {  
        printf("shmget failed\n");
        return -1;
    }
	shm = (char *)shmat(shmid, (void*)0, 0);				//将共享内存连接到当前进程的地址空间
	*shm = 0;
	printf("shm=%d\n", *shm);
	return 0;
}


int exit_encode(void)
{
	VideoEncDestroy(pVideoEnc);
	CdcMemClose(baseConfig.memops);
}




int run_encode(unsigned char *yuv420PBuffer, FILE *H264_file)
{
	int i;
	static long long pts = 0;
	static long long time1=0;
	static long long time2=0;
	VencInputBuffer inputBuffer;
	VencOutputBuffer outputBuffer;
	
	GetOneAllocInputBuffer(pVideoEnc, &inputBuffer);
	
	memcpy(inputBuffer.pAddrVirY, yuv420PBuffer, H264IMAGE_WIDTH * H264IMAGE_HEIGHT);
	memcpy(inputBuffer.pAddrVirC, yuv420PBuffer + H264IMAGE_WIDTH * H264IMAGE_HEIGHT, H264IMAGE_WIDTH * H264IMAGE_HEIGHT / 2);
	
    inputBuffer.bEnableCorp = 0;
    inputBuffer.sCropInfo.nLeft =  240;
    inputBuffer.sCropInfo.nTop  =  240;
    inputBuffer.sCropInfo.nWidth  =  240;
    inputBuffer.sCropInfo.nHeight =  240;
    FlushCacheAllocInputBuffer(pVideoEnc, &inputBuffer);
    pts += 1*1000/H264PERFRAME;
    inputBuffer.nPts = pts;
    AddOneInputBuffer(pVideoEnc, &inputBuffer);
	
    //time1 = GetNowUs();
	while(*shm != 0){
		usleep(100);
	}
	*shm = 1;
    VideoEncodeOneFrame(pVideoEnc);
	*shm = 0;
    //time2 = GetNowUs();
    //logv("encode frame %d use time is %lldus..\n",testNumber,(time2-time1));

    AlreadyUsedInputBuffer(pVideoEnc,&inputBuffer);
    ReturnOneAllocInputBuffer(pVideoEnc, &inputBuffer);

    if(GetOneBitstreamFrame(pVideoEnc, &outputBuffer) == -1)
    {
		printf("GetOneBitstreamFrame fail\n");
        return -1;
    }
	
    fwrite(outputBuffer.pData0, 1, outputBuffer.nSize0, H264_file);
	
	//printf("outputBuffer.nSize0: %d\n", outputBuffer.nSize0);
	//for(i = 0; i < outputBuffer.nSize0; i++)
	//	printf("0x%x ", *(outputBuffer.pData0 + i));
	//printf("\n");
	send_rtmp_h264(outputBuffer.pData0, outputBuffer.nSize0);
	
    if(outputBuffer.nSize1)
    {
       fwrite(outputBuffer.pData1, 1, outputBuffer.nSize1, H264_file);
    }

    FreeOneBitStreamFrame(pVideoEnc, &outputBuffer);

	
	return 1;
}








