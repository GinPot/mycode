#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>

#include <linux/videodev2.h>

#include "drm_display.h"


#define VIDEO_DEV		"/dev/video0"
#define IMAGE_WIDTH		640
#define IMAGE_HEIGHT	360
#define BUFFER_NUM		2

struct buffer_info{
	unsigned char *image_buffer;
	int length;
};


int InitUvcCamera(int *video_fd, struct buffer_info *bufferinfo, struct buffer_object *buf);


#endif	/* __UVC_CAMERA_H__ */