#include "camera.h"
#include "yuv_to_jpg.h"
#include "drm_display.h"



static void modeset_page_flip_handler(int fd, uint32_t frame, uint32_t sec, uint32_t usec, void *data);

void OutPutFpsInfo()
{
	static int fps = 1; 
	struct timezone tz;
	static struct timeval tv_old, tv_new;
	float usec = 0, sec = 0, time = 0;

	if((fps%60) == 0){
		fps = 1;
		gettimeofday(&tv_old, &tz);
	}else{
		fps++;
		if(60 == fps){
			gettimeofday(&tv_new, &tz);
			if(tv_new.tv_usec >= tv_old.tv_usec){
				usec = tv_new.tv_usec - tv_old.tv_usec;
				sec = tv_new.tv_sec - tv_old.tv_sec;
			}else{
				usec = 1000000 + tv_new.tv_usec - tv_old.tv_usec;
				sec = tv_new.tv_sec - tv_old.tv_sec - 1;
			}
			time = sec + usec/1000000;
			printf("the fps is %f\n", 60/time);
		}
	}
}

void yuyv2bgr24(unsigned char*yuyv, unsigned char*rgb)
{   
	unsigned int width = IMAGE_WIDTH;
    unsigned int height = IMAGE_HEIGHT;
    unsigned int i, in, rgb_index = 0;
    unsigned char y0, u0, y1, v1;
    int r, g, b, len = width * height * 2;
    unsigned int x , y;

    for(in = 0; in < len; in += 4)
    {
		y0 = yuyv[in + 0];
		u0 = yuyv[in + 1];
		y1 = yuyv[in + 2];
		v1 = yuyv[in + 3];

		for (i = 0; i < 2; i++)
		{
			if (i)
				y = y1;
			else
				y = y0;
			r = y + (140 * (v1 - 128)) / 100;  						//r
			g = y - (34  * (u0 - 128)) / 100 - (71 * (v1 - 128)) / 100; //g
			b = y + (177 * (u0 - 128)) / 100; 						//b
			
			if(r > 255) r = 255;
			if(g > 255) g = 255;
			if(b > 255) b = 255;
			if(r < 0)   r = 0;
			if(g < 0)   g = 0;
			if(b < 0)   b = 0;

			y = height - rgb_index / width -1;
			x = rgb_index % width;
			rgb[(y * width + x) * 3 + 0] = b;
			rgb[(y * width + x) * 3 + 1] = g;
			rgb[(y * width + x) * 3 + 2] = r;
			rgb_index++;
		}
    }
}

struct buffer_object buf;
struct v4l2_buffer video_buffer;
int main(int argc, char **argv)
{
	FILE *jpg_file;
	char jpg_file_name[100];
	int video_fd, jpg_cnt=0, jpg_size, i;
	drmModeConnector *conn;
	drmEventContext ev = {};
	struct buffer_info bufferinfo[BUFFER_NUM];
	unsigned char *jpg_p = malloc(IMAGE_WIDTH*IMAGE_HEIGHT*3);
	
	unsigned char *dstBuffer_1 = (unsigned char*)malloc(sizeof(unsigned char) * IMAGE_WIDTH * IMAGE_HEIGHT * 3);

	
	
	
	if(jpg_p == NULL){
		printf("no memory\n");
		return 0;
	}


	if(InitDrmDisplay(&buf, conn) < 0){
		printf("init drm fail\n");
		return 0;
	}
	
	if(InitUvcCamera(&video_fd, bufferinfo, &buf) < 0){
		printf("init uvc camera fail\n");
		return 0;
	}
	
	ev.version = DRM_EVENT_CONTEXT_VERSION;
	ev.page_flip_handler = modeset_page_flip_handler;
	
	while(1){
		memset(&video_buffer, 0, sizeof(&video_buffer));
		video_buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		video_buffer.memory = V4L2_MEMORY_DMABUF;
		if(ioctl(video_fd, VIDIOC_DQBUF, &video_buffer) < 0){		//取出队列采集完毕的缓冲区
			printf("get camera buffer fail\n");
			return 0;
		}

		drmHandleEvent(buf.drm_fd, &ev);							//等待vsync事件再刷新
		
		//memcpy(buf.vaddr, bufferinfo[video_buffer.index].image_buffer, IMAGE_WIDTH * IMAGE_HEIGHT * 2);
		//buf.req = drmModeAtomicAlloc();
		//drmModeAtomicAddProperty(buf.req, buf.plane_id, buf.property_plane_id, buf.fb_id[video_buffer.index]);
		//drmModeAtomicCommit(buf.drm_fd, buf.req, 0, NULL);
		//drmModeAtomicFree(buf.req);


		//legacy display
		//yuyv2bgr24(bufferinfo[video_buffer.index].image_buffer, dstBuffer_1);
		//for(i = 0; i < 360; i++){
		//	memcpy(buf.vaddr + ((i+60)*800+80)*3, dstBuffer_1 + i * 640*3, 640*3);
		//}
		//drmModeSetCrtc(buf.drm_fd, buf.crtc_id, buf.fb_id, 0, 0, &buf.conn_id, 1, &conn->modes[0]);
		//drmModeSetPlane(buf.drm_fd, buf.plane_id, buf.crtc_id, buf.fb_id, 0,
		//	0, 0, 800, 480,
		//	0, 0, 640 << 16, 360 << 16);
		 
		/*YUV数据转JPEG格式*/
		//jpg_size=yuv_to_jpeg(IMAGE_WIDTH, IMAGE_HEIGHT, IMAGE_HEIGHT*IMAGE_WIDTH*3, bufferinfo[video_buffer.index].image_buffer, jpg_p, 80);
		//sprintf(jpg_file_name,"./jpg/%d.jpg",jpg_cnt++);
		//printf("图片名称:%s,字节大小:%d\n",jpg_file_name, jpg_size);
		//jpg_file=fopen(jpg_file_name, "wb");
		//fwrite(jpg_p, jpg_size, 1, jpg_file);
		//fclose(jpg_file);		

		//jpg_file=fopen("./jpg/out.yuv", "wb");
		//fwrite(jpg_p, jpg_size, 1, jpg_file);
		//fclose(jpg_file);	
		 
		if(ioctl(video_fd, VIDIOC_QBUF, &video_buffer) < 0){		//将缓冲区再放入队列
			printf("set camera buffer fail\n");
			return 0;
		}
		
		OutPutFpsInfo();
	}
	
	

	return 0;
}

static void modeset_page_flip_handler(int fd, uint32_t frame, uint32_t sec, uint32_t usec, void *data)
{
	buf.req = drmModeAtomicAlloc();
	drmModeAtomicAddProperty(buf.req, buf.plane_id, buf.property_plane_id, buf.fb_id[video_buffer.index]);
	drmModeAtomicCommit(buf.drm_fd, buf.req, DRM_MODE_PAGE_FLIP_EVENT, NULL);
	drmModeAtomicFree(buf.req);
}








