#include "drm_display.h"
#include "camera.h"

static void printgPropertyName(int fd, drmModeObjectProperties *props)
{
	drmModePropertyPtr property;
	uint32_t i;
	
	for(i = 0; i < props->count_props; i++){
		property = drmModeGetProperty(fd, props->props[i]);
		printf("    %s\n", property->name);
		drmModeFreeProperty(property);
	}
}

static uint32_t get_property_id(int fd, drmModeObjectProperties *props, const char *name){
	drmModePropertyPtr property;
	uint32_t i, id = 0;
	
	for(i = 0; i < props->count_props; i++){
		property = drmModeGetProperty(fd, props->props[i]);
		if(!strcmp(property->name, name))
			id = property->prop_id;
		drmModeFreeProperty(property);
		
		if(id)
			break;
	}
	return id;
}

static int buff_create(struct buffer_object *buf, int i)
{
	struct drm_mode_create_dumb create = {};
	struct drm_prime_handle prime;
	int ret;

	create.width = IMAGE_WIDTH;//buf->width;									//显示buffer的创建，可以不匹配分辨率
	create.height = IMAGE_HEIGHT;//buf->height;
	create.bpp = 16;															//RGB:24, YUYV:16
	if(drmIoctl(buf->drm_fd, DRM_IOCTL_MODE_CREATE_DUMB, &create) < 0){
		printf("create dumb fail\n");
		return -1;
	}
	
	buf->pitch = create.pitch;													//每一行的字节数: create.width * create.bpp
	buf->size = create.size;
	buf->handle = create.handle;

	uint32_t offsets[4] = { 0 };
	uint32_t pitches[4] = { create.pitch };
	uint32_t bo_handles[4] = { create.handle };
	if(drmModeAddFB2(buf->drm_fd, create.width, create.height, DRM_FORMAT_YUYV, bo_handles, pitches, offsets, &buf->fb_id[i], 0) < 0){			//指定要显示数据格式
		printf("add fb fail\n");
		return -1;
	}


	memset(&prime, 0, sizeof(struct drm_prime_handle));
	prime.handle = create.handle;
	ret = ioctl(buf->drm_fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &prime);
	if(ret < 0){
		printf("PRIME_HANDLE_TO_FD fail\n");
		return -1;
	}
	buf->dbuf_fd[i] = prime.fd;
	
	
	return 0;
}



int InitDrmDisplay(struct buffer_object *buf, drmModeConnector *conn)
{
	int drm_fd, i, j;
	
	drmModeRes *res;
	
	
	drmModePlaneRes *plane_res;
	drmModePlane *plane_mode;

	drmModeObjectProperties *props;
	
	uint32_t property_active, property_mode_id;
	uint32_t property_crtc_id, property_crtc_x, property_crtc_y, property_crtc_w, property_crtc_h;
	uint32_t property_plane_id, property_src_x, property_src_y, property_src_w, property_src_h, property_zpos;


	struct drm_mode_map_dumb map = {};
	
	
	
	printf("\n********Init drm display********\n\n");

	drm_fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
	buf->drm_fd = drm_fd;

/****************************************************************************************/
	
	res = drmModeGetResources(drm_fd);
	buf->crtc_id = res->crtcs[0];
	buf->conn_id = res->connectors[0];
	
	conn = drmModeGetConnector(drm_fd, buf->conn_id);
	buf->width = conn->modes[0].hdisplay;
	buf->height = conn->modes[0].vdisplay;


	
/****************************************************************************************/

	drmSetClientCap(drm_fd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 1);				//不运行这个只会得到没使用的plane
	plane_res = drmModeGetPlaneResources(drm_fd);
	
	for(i = 0; i < plane_res->count_planes; i++){
		printf("PlaneId[%d]=%d\n", i, plane_res->planes[i]);
		plane_mode = drmModeGetPlane(drm_fd, plane_res->planes[i]);
		for(j = 0; j < plane_mode->count_formats; j++){
			//fprintf(stderr, "    FB format %c%c%c%c\n",
			//									plane_mode->formats[j],
			//									plane_mode->formats[j] >> 8,
			//									plane_mode->formats[j] >> 16,
			//									plane_mode->formats[j] >> 24);
			if(plane_mode->formats[j] == V4L2_PIX_FMT_YUYV){
				printf("    support DRM_FORMAT_YUYV\n");
				buf->plane_id = plane_res->planes[i];							//取支持格式的plane
				break;
			}
		}
		if(buf->plane_id)
			break;
	}

	printf("\nplane_id=%d, crtc_id=%d, conn_id=%d, size=%dx%d\n", buf->plane_id, buf->crtc_id, buf->conn_id, buf->width, buf->height);

/****************************************************************************************/
	for(i = 0; i < BUFFER_NUM; i++)
		buff_create(buf, i);

//	create.width = IMAGE_WIDTH;//buf->width;									//显示buffer的创建，可以不匹配分辨率
//	create.height = IMAGE_HEIGHT;//buf->height;
//	create.bpp = 16;															//RGB:24, YUYV:16
//	if(drmIoctl(drm_fd, DRM_IOCTL_MODE_CREATE_DUMB, &create) < 0){
//		printf("create dumb fail\n");
//		return -1;
//	}
//
//	buf->pitch = create.pitch;													//每一行的字节数: create.width * create.bpp
//	buf->size = create.size;
//	buf->handle = create.handle;
//
//	uint32_t offsets[4] = { 0 };
//	uint32_t pitches[4] = { create.pitch };
//	uint32_t bo_handles[4] = { create.handle };
//	if(drmModeAddFB2(drm_fd, create.width, create.height, DRM_FORMAT_YUYV, bo_handles, pitches, offsets, &buf->fb_id, 0) < 0){			//指定要显示数据格式
//		printf("add fb fail\n");
//		return -1;
//	}
//	
//	//if(drmModeAddFB(drm_fd, buf->width, buf->height, 16, 16, buf->pitch, buf->handle, &buf->fb_id) < 0){
//	//	printf("add fb fail\n");
//	//	return -1;
//	//}	
//	
//
//	map.handle = create.handle;
//	if(drmIoctl(drm_fd, DRM_IOCTL_MODE_MAP_DUMB, &map) < 0){
//		printf("map dumb fail\n");
//		return -1;
//	}
//
//	buf->vaddr = mmap(0, create.size, PROT_READ | PROT_WRITE, MAP_SHARED, drm_fd, map.offset);
//	if(buf->vaddr == NULL){
//		printf("mmap fail\n");
//		return -1;
//	}
//	//memset(buf->vaddr, 0xaa, buf->size);
//	printf("\nset buf:\n    %dx%d\n    bytesperline=%d\n    buf->size=%d\n", create.width, create.height, buf->pitch, buf->size);

/****************************************************************************************/

	drmSetClientCap(buf->drm_fd, DRM_CLIENT_CAP_ATOMIC, 1);
	
	props = drmModeObjectGetProperties(buf->drm_fd, buf->conn_id, DRM_MODE_OBJECT_CONNECTOR);
	//printf("\nCONNECTOR proper:\n");
	//printgPropertyName(buf->drm_fd, props);
	property_crtc_id = get_property_id(buf->drm_fd, props, "CRTC_ID");;
	drmModeFreeObjectProperties(props);

	props = drmModeObjectGetProperties(buf->drm_fd, buf->crtc_id, DRM_MODE_OBJECT_CRTC);
	//printf("\nCRTC proper:\n");
	//printgPropertyName(buf->drm_fd, props);
	property_active = get_property_id(buf->drm_fd, props, "ACTIVE");
	property_mode_id = get_property_id(buf->drm_fd, props, "MODE_ID");
	drmModeFreeObjectProperties(props);

	drmModeCreatePropertyBlob(buf->drm_fd, &conn->modes[0], sizeof(conn->modes[0]), &buf->blob_id);
	
	buf->req = drmModeAtomicAlloc();
	drmModeAtomicAddProperty(buf->req, buf->crtc_id, property_active, 1);
	drmModeAtomicAddProperty(buf->req, buf->crtc_id, property_mode_id, buf->blob_id);
	drmModeAtomicAddProperty(buf->req, buf->conn_id, property_crtc_id, buf->crtc_id);
	drmModeAtomicCommit(buf->drm_fd, buf->req, DRM_MODE_ATOMIC_ALLOW_MODESET, NULL);
	drmModeAtomicFree(buf->req);
	
	printf("\ndrmModeAtomicCommit SetCrtc\n");

//================================	
	
	props = drmModeObjectGetProperties(buf->drm_fd, buf->plane_id, DRM_MODE_OBJECT_PLANE);
	//printf("\nPLANE proper:\n");
	//printgPropertyName(buf->drm_fd, props);	
	property_crtc_id = get_property_id(buf->drm_fd, props, "CRTC_ID");
	property_crtc_x = get_property_id(buf->drm_fd, props, "CRTC_X");
	property_crtc_y = get_property_id(buf->drm_fd, props, "CRTC_Y");
	property_crtc_w = get_property_id(buf->drm_fd, props, "CRTC_W");
	property_crtc_h = get_property_id(buf->drm_fd, props, "CRTC_H");

	property_plane_id = get_property_id(buf->drm_fd, props, "FB_ID");
	property_src_x = get_property_id(buf->drm_fd, props, "SRC_X");
	property_src_y = get_property_id(buf->drm_fd, props, "SRC_Y");
	property_src_w = get_property_id(buf->drm_fd, props, "SRC_W");
	property_src_h = get_property_id(buf->drm_fd, props, "SRC_H");
	
	property_zpos = get_property_id(buf->drm_fd, props, "zpos");

	
	buf->req = drmModeAtomicAlloc();
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_crtc_id, buf->crtc_id);		//把plane放在多大的窗口显示，不匹配则会对应的缩放
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_crtc_x, 80);
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_crtc_y, 60);
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_crtc_w, 640);
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_crtc_h, 360);

	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_plane_id, buf->fb_id[0]);		//截取plane buffer里的数据，
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_src_x, 0);
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_src_y, 0);
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_src_w, 640 << 16);
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_src_h, 360 << 16);
	
	drmModeAtomicAddProperty(buf->req, buf->plane_id, property_zpos, 1);						//设置层级

	drmModeAtomicCommit(buf->drm_fd, buf->req, DRM_MODE_PAGE_FLIP_EVENT, NULL);
	buf->property_plane_id = property_plane_id;
	drmModeAtomicFree(buf->req);
	
	printf("\ndrmModeAtomicCommit SetPlane\n\n");
	
	
	
	
	
	
	
	//memset(buf->vaddr, 0xaa, buf->size);
	//drmModeSetCrtc(buf->drm_fd, buf->crtc_id, buf->fb_id, 0, 0, &buf->conn_id, 1, &conn->modes[0]);
	
	return 0;
}
















