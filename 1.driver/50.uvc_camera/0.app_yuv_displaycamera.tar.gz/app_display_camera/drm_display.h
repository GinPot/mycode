#ifndef __DRM_DISPLAY_H__
#define __DRM_DISPLAY_H__

#include <stdio.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm_fourcc.h>

#include <linux/videodev2.h>




#define BUFFER_NUM		2

struct buffer_object {
	int drm_fd;
	uint32_t crtc_id;
	uint32_t conn_id;
	uint32_t plane_id;
	uint32_t blob_id;

	uint32_t width;
	uint32_t height;
	uint32_t pitch;
	uint32_t handle;
	uint32_t size;
	uint8_t *vaddr;
	uint32_t fb_id[BUFFER_NUM];
	
	int dbuf_fd[BUFFER_NUM];
	
	drmModeAtomicReq *req;
	uint32_t property_plane_id;
};


int InitDrmDisplay(struct buffer_object *buf, drmModeConnector *conn);



#endif	/* __DRM_DISPLAY_H__ */